import accounts_csv
import config
import push


def _emit_checkin_result_logs(message):
    """Forward per-game results to FunctionGraph/LTS with account context."""
    game_names = ("崩坏学园2", "崩坏3rd", "未定事件簿", "原神", "崩坏：星穹铁道", "绝区零")
    current_game = "其他"
    account_context = ""
    for raw_line in str(message or "").splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if line.startswith("[账号上下文]"):
            account_context = line.replace("[账号上下文]", "").strip()
            current_game = "其他"
            continue
        if line.startswith("[账号执行结束]"):
            continue
        empty_header = False
        for name in game_names:
            if line == name + "：" or line == name + ":":
                current_game = name
                empty_header = True
                break
            if line.startswith(name + "：") or line.startswith(name + ":"):
                current_game = name
                break
        if not empty_header:
            print("[签到结果][{}]{} {}".format(current_game, account_context, line), flush=True)


def main_handler(event: dict, context: dict):
    config.serverless = True
    try:
        status_code, push_message = accounts_csv.run_accounts(context=context)
    except Exception as exc:
        status_code = 1
        push_message = "CSV 账号配置或执行失败：%s: %s" % (type(exc).__name__, exc)
        print(push_message, flush=True)
    _emit_checkin_result_logs(push_message)
    push.push(status_code, push_message)
    print("HoYoLAB CSV 云函数执行完毕！", flush=True)
    return 0
