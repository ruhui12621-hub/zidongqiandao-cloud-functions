#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

rm -rf dist build index.spec
mkdir -p dist/cloud_functions
pyinstaller --noconfirm --clean --onedir --name index \
  --distpath "$ROOT/dist/cloud_functions" \
  "$ROOT/src/index.py"

touch "$ROOT/dist/cloud_functions/INPUT_HYPERGRYPH_TOKEN.txt"
install -m 755 "$ROOT/.build/bootstrap" "$ROOT/dist/cloud_functions/bootstrap"
